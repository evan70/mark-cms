<img src="{{ asset('images/tech/' . $tech . '.svg') }}" 
     alt="{{ $tech }}" 
     class="w-16 h-16">