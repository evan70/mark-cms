<?php

return [
    'sk' => 'Slovenčina',
    'en' => 'Angličtina',
    'cs' => 'Čeština',
];
