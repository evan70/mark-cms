<?php

return [
    'en' => 'English',
    'sk' => 'Slovak',
    'cs' => 'Czech',
];