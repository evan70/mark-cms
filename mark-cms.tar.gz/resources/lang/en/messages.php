<?php

return [
    'Welcome to our Blog' => 'Welcome to our Blog',
    'Discover our latest articles and updates' => 'Discover our latest articles and updates',
    'Current language' => 'Current language',
    
    // Menu items
    'Home' => 'Home',
    'Articles' => 'Articles',
    'Categories' => 'Categories',
    
    // Common
    'Published' => 'Published',
    'Read more' => 'Read more'
];