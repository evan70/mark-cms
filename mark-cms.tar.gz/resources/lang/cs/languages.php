<?php

return [
    'sk' => 'Slovenština',
    'en' => 'Angličtina',
    'cs' => 'Čeština',
];
